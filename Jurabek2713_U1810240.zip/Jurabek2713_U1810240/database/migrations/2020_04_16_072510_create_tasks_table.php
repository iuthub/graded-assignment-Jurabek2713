<?php

//** To_create_tasks_table.php */
//** Name: Uzakov Jurabek */
//** Id: U1810240 */
//** Sec001*/
//** CIE18_02




use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTasksTable extends Migration
{
 /** To run the migration */

    public function up()
    {
        Schema::create('tasks', function (Blueprint $table) {
        $table->increments('id');
        $table->string('name');
        $table->timestamps();
        });
    }

    /** For reversing migrations */
    public function down()
    {
        Schema::dropIfExists('tasks');
    }
}
