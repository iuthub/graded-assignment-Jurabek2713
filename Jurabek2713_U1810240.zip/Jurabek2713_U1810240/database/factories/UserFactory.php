<?php

//** UseFactory.php */
//** Name: Uzakov Jurabek */
//** Id: U1810240 */
//** Sec001*/
//** CIE18_02




use App\User;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

	$factory->define(User::class, function (Faker $faker) {
    	return ['name' => $faker->title];
});
