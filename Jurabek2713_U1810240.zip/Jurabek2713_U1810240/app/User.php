<?php

//** User.php */
//** Name: Uzakov Jurabek */
//** Id: U1810240 */
//** Sec001*/
//** CIE18_02

 

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * Mass assignable attributes */

    protected $fillable = ['name', 'email', 'password'];

    /** Attributes which have to be hidden for arrays */
    
    protected $hidden = ['password', 'remember_token'];

    /**
     * The attributes that should be cast to native types. */

    protected $casts = ['email_verified_at' => 'datetime'];}