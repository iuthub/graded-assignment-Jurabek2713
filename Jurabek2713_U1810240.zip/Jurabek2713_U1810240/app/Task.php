<?php

// Task.php */
//** Name: Uzakov Jurabek */
//** Id: U1810240 */
//** Sec001*/
//** CIE18_02

namespace App;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    
}
