<?php

// web.php */
//** Name: Uzakov Jurabek */
//** Id: U1810240 */
//** Sec001*/
//** CIE18_02



use Illuminate\Support\Facades\Route;
use App\Task;
use Illuminate\Http\Request;

Route::group(['middleware' => ['web']], function () {
    
    /** Demonstrating Task Dashboard */

    Route::get('/', function () {
        return view('tasks', [
            'tasks' => Task::orderBy('created_at', 'asc')->get()
        ]);
    });

    /** For adding a new Task */

    Route::post('/task', function (Request $request) {
            $validator = Validator::make($request->all(), [
                'name' => 'required|max:255',]);

        if ($validator->fails()) {
            return redirect('/')
                ->withInput()
                ->withErrors($validator);
        }

    $task = new Task;
    $task->name = $request->name;
    $task->save();

        return redirect('/');
    });

    
    /** For deleting task */
    
    Route::delete('/task/{id}', function ($id) {
        Task::findOrFail($id)->delete();

        return redirect('/');
    });
});